/*
 * Task_TCP_Transmit.h
 *
 *  Created on: Sep. 20, 2023
 *      Author: David
 */

#ifndef APPS_TASK_TCP_TRANSMIT_H_
#define APPS_TASK_TCP_TRANSMIT_H_


void TASK_TCP_TRANSMIT_INIT(void *arg);


#endif /* APPS_TASK_TCP_TRANSMIT_H_ */
