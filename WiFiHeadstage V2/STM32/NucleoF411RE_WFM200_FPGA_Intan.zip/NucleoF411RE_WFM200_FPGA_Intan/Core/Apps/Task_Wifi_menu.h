/*
 * wifi_menu.h
 *
 *  Created on: Aug. 14, 2023
 *      Author: david
 */

#ifndef APPS_TASK_WIFI_MENU_H_
#define APPS_TASK_WIFI_MENU_H_

void WIFI_MENU_INIT(void *arg);


#endif /* APPS_TASK_WIFI_MENU_H_ */
