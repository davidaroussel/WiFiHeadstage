/*
 * udp_task.h
 *
 *  Created on: Oct 2, 2022
 *      Author: david
 */

#ifndef INC_UDP_TASK_H_
#define INC_UDP_TASK_H_




void TASK_UDP_TRANSMIT_INIT(void *arg);
int INIT_UPD(void);



#endif /* INC_UDP_TASK_H_ */
