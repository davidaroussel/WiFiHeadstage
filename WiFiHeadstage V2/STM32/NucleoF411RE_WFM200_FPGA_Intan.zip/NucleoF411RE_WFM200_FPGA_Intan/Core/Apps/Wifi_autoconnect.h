/*
 * wifi_autoconnect.h
 *
 *  Created on: Sep. 30, 2022
 *      Author: David
 */

#ifndef INC_WIFI_AUTOCONNECT_H_
#define INC_WIFI_AUTOCONNECT_H_

void wifi_autoconnexion_init(void);

#endif /* INC_WIFI_AUTOCONNECT_H_ */
