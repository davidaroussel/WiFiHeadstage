/*
 * Trace Recorder for Tracealyzer v4.6.6
 * Copyright 2021 Percepio AB
 * www.percepio.com
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Kernel port configuration parameters for streaming mode.
 */

#ifndef TRC_KERNEL_PORT_STREAMING_CONFIG_H
#define TRC_KERNEL_PORT_STREAMING_CONFIG_H

#ifdef __cplusplus
extern "C" {
#endif

/* Nothing yet */

#ifdef __cplusplus
}
#endif

#endif /* TRC_KERNEL_PORT_STREAMING_CONFIG_H */
